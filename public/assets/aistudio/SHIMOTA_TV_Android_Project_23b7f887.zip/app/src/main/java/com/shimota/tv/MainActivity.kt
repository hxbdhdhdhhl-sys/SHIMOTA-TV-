package com.shimota.tv

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.navigation.compose.*
import coil.compose.AsyncImage

private val Black = Color(0xFF09090D)
private val Gold = Color(0xFFD8B46A)
private val Muted = Color(0xFF9A9AA5)
private val Panel = Color(0xFF17171F)

data class Show(val id:String,val title:String,val kind:String,val year:String,val genre:String,val synopsis:String,val poster:String,val streamUrl:String="")

private val catalogue = listOf(
    Show("a1","The Silent City","Series","2025","Drama","A mystery unfolds in a city where every secret has a price.","https://images.unsplash.com/photo-1489599849927-2ee91cado3ba?w=800"),
    Show("a2","Beyond The Horizon","Movie","2024","Adventure","An expedition discovers a world beyond the maps.","https://images.unsplash.com/photo-1519608487953-e999c86e7455?w=800"),
    Show("a3","Night Signal","Series","2025","Thriller","A late-night broadcast changes everything.","https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=800")
)

class MainActivity:ComponentActivity(){
    override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContent{ App() }}
}

@Composable fun App(){
    val nav= rememberNavController()
    var tab by remember { mutableStateOf("home") }
    var saved by remember { mutableStateOf(setOf<String>()) }
    MaterialTheme(colorScheme=darkColorScheme(background=Black,surface=Panel,primary=Gold)){
        Scaffold(containerColor=Black,bottomBar={
            NavigationBar(containerColor=Panel){
                listOf("home" to Icons.Default.Home,"search" to Icons.Default.Search,"saved" to Icons.Default.Bookmark,"profile" to Icons.Default.Person).forEach{(route,ic)->
                    NavigationBarItem(selected=tab==route,onClick={tab=route;nav.navigate(route){launchSingleTop=true}},icon={Icon(ic,null)},label={Text(mapOf("home" to "الرئيسية","search" to "بحث","saved" to "قائمتي","profile" to "حسابي")[route]!!)})
                }
            }
        }){pad->
            NavHost(nav,"home",Modifier.padding(pad)){
                composable("home"){Home{nav.navigate("detail/${it.id}")}}
                composable("search"){Search{nav.navigate("detail/${it.id}")}}
                composable("saved"){Saved(saved){nav.navigate("detail/${it.id}")}}
                composable("profile"){Profile()}
                composable("detail/{id}"){e->catalogue.firstOrNull{it.id==e.arguments?.getString("id")}?.let{s->Detail(s,s.id in saved,{saved=if(s.id in saved)saved-s.id else saved+s.id},{nav.navigate("player/${s.id}")})}}
                composable("player/{id}"){e->catalogue.firstOrNull{it.id==e.arguments?.getString("id")}?.let{Player(it)}}
            }
        }
    }
}

@Composable private fun BrandHeader(){
    Row(Modifier.fillMaxWidth().padding(20.dp),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){
        Column{Text("SHIMOTA",color=Gold,fontSize=25.sp,fontWeight=FontWeight.Black,letterSpacing=2.sp);Text("TV  •  YOUR CINEMA",color=Muted,fontSize=10.sp,letterSpacing=2.sp)}
        Icon(Icons.Default.NotificationsNone,null,tint=Color.White)
    }
}
@Composable private fun Home(open:(Show)->Unit){
    LazyColumn(contentPadding=PaddingValues(bottom=18.dp)){
        item{BrandHeader()}
        item{Column(Modifier.padding(horizontal=18.dp)){
            Text("قصتك تبدأ هنا",fontSize=27.sp,fontWeight=FontWeight.Bold)
            Text("اكتشف أفلاماً ومسلسلات تستحق المشاهدة",color=Muted,fontSize=13.sp)
            Spacer(Modifier.height(18.dp))
            catalogue.firstOrNull()?.let{s->
                Box(Modifier.fillMaxWidth().height(220.dp).clip(RoundedCornerShape(22.dp)).clickable{open(s)}){
                    AsyncImage(s.poster,s.title,Modifier.fillMaxSize())
                    Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha=.58f)))
                    Column(Modifier.align(Alignment.BottomStart).padding(18.dp)){
                        Text("اختيار مميز",color=Gold);Text(s.title,fontSize=26.sp,fontWeight=FontWeight.Bold)
                        Text("${s.kind} • ${s.year} • ${s.genre}",color=Color.LightGray,fontSize=12.sp)
                        Spacer(Modifier.height(8.dp))
                        Button(onClick={open(s)},colors=ButtonDefaults.buttonColors(containerColor=Gold,contentColor=Black)){Icon(Icons.Default.PlayArrow,null);Text("اكتشف الآن")}
                    }
                }
            }
            Spacer(Modifier.height(22.dp));Text("مختارات SHIMOTA",fontSize=20.sp,fontWeight=FontWeight.Bold)
        }}
        items(catalogue){ShowCard(it,open)}
    }
}
@Composable private fun ShowCard(s:Show,open:(Show)->Unit){
    Row(Modifier.fillMaxWidth().clickable{open(s)}.padding(horizontal=18.dp,vertical=9.dp),verticalAlignment=Alignment.CenterVertically){
        AsyncImage(s.poster,s.title,Modifier.size(104.dp,128.dp).clip(RoundedCornerShape(12.dp)))
        Column(Modifier.weight(1f).padding(start=14.dp)){Text(s.title,fontSize=17.sp,fontWeight=FontWeight.Bold);Text("${s.kind} • ${s.year}",color=Gold,fontSize=12.sp);Spacer(Modifier.height(5.dp));Text(s.synopsis,color=Muted,fontSize=12.sp,maxLines=3)}
        Icon(Icons.Default.ChevronRight,null,tint=Muted)
    }
}
@Composable private fun Search(open:(Show)->Unit){
    var q by remember{mutableStateOf("")};var kind by remember{mutableStateOf("الكل")}
    Column{BrandHeader();OutlinedTextField(q,{q=it},Modifier.fillMaxWidth().padding(horizontal=16.dp),label={Text("ابحث عن فيلم أو مسلسل")},leadingIcon={Icon(Icons.Default.Search,null)},singleLine=true)
        Row(Modifier.padding(16.dp),horizontalArrangement=Arrangement.spacedBy(8.dp)){listOf("الكل","Movie","Series").forEach{FilterChip(kind==it,{kind=it},{Text(when(it){"Movie"->"أفلام";"Series"->"مسلسلات";else->"الكل"})})}}
        LazyColumn{items(catalogue.filter{(it.title.contains(q,true)||it.genre.contains(q,true))&&(kind=="الكل"||it.kind==kind)}){ShowCard(it,open)}}
    }
}
@Composable private fun Saved(ids:Set<String>,open:(Show)->Unit){
    Column{BrandHeader();Text("قائمتي",Modifier.padding(horizontal=18.dp),fontSize=24.sp,fontWeight=FontWeight.Bold)
        val rows=catalogue.filter{it.id in ids};if(rows.isEmpty())Text("لم تضف أي عنوان إلى قائمتك بعد",Modifier.padding(20.dp),color=Muted) else LazyColumn{items(rows){ShowCard(it,open)}}
    }
}
@Composable private fun Detail(s:Show,fav:Boolean,toggle:()->Unit,play:()->Unit){
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())){
        AsyncImage(s.poster,s.title,Modifier.fillMaxWidth().height(330.dp))
        Column(Modifier.padding(20.dp)){Text(s.title,fontSize=28.sp,fontWeight=FontWeight.Bold);Text("${s.kind} • ${s.year} • ${s.genre}",color=Gold);Spacer(Modifier.height(12.dp));Text(s.synopsis,color=Muted,lineHeight=22.sp);Spacer(Modifier.height(22.dp))
            Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){Button(play,colors=ButtonDefaults.buttonColors(containerColor=Gold,contentColor=Black)){Icon(Icons.Default.PlayArrow,null);Text("تشغيل")};OutlinedButton(toggle){Icon(if(fav)Icons.Default.Bookmark else Icons.Default.BookmarkBorder,null);Text(if(fav)"أُضيفت للقائمة" else "أضف للمفضلة")}}
            Spacer(Modifier.height(20.dp));Text("الحلقات والمواسم",fontWeight=FontWeight.Bold,fontSize=18.sp);Text("تُضاف بيانات الحلقات عند ربط كتالوج التوزيع المرخّص.",color=Muted,fontSize=12.sp)
        }
    }
}
@Composable private fun Player(s:Show){
    val ctx=LocalContext.current
    val player=remember(s.id){ExoPlayer.Builder(ctx).build().apply{if(s.streamUrl.isNotBlank()){setMediaItem(MediaItem.fromUri(s.streamUrl));prepare()}}}
    DisposableEffect(player){onDispose{player.release()}}
    Column(Modifier.fillMaxSize().background(Color.Black),verticalArrangement=Arrangement.Center,horizontalAlignment=Alignment.CenterHorizontally){
        if(s.streamUrl.isBlank()){Text("SHIMOTA TV PLAYER",color=Gold,fontSize=20.sp);Text("أضف رابط بث مرخّص لهذا العنوان لتفعيل التشغيل.",Modifier.padding(24.dp),color=Color.White)}
        else AndroidView(factory={PlayerView(it).apply{this.player=player}},modifier=Modifier.fillMaxWidth().aspectRatio(16f/9f))
    }
}
@Composable private fun Profile(){
    Column{BrandHeader();Text("حسابك",Modifier.padding(horizontal=20.dp),fontSize=26.sp,fontWeight=FontWeight.Bold)
        listOf("اللغة: العربية","المظهر: سينمائي","سياسة الخصوصية","حول SHIMOTA TV").forEach{ListItem(headlineContent={Text(it)},leadingContent={Icon(Icons.Default.ChevronRight,null)},colors=ListItemDefaults.colors(containerColor=Black,headlineColor=Color.White))}
    }
}
